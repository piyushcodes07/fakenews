import { NextApiRequest, NextApiResponse } from 'next';
import { TavilySearchResults } from "@langchain/community/tools/tavily_search";
import { LLMChain } from 'langchain/chains';
import { PromptTemplate } from "@langchain/core/prompts";
import { ChatGoogleGenerativeAI } from '@langchain/google-genai';
import { config } from 'dotenv';

config();

const tavilySearch = new TavilySearchResults({
    searchDepth: "deep",
    topic: "news"
});

async function searchAndSummarize(query: string) {
    const searchResults = await tavilySearch.invoke(query);
    const llm = new ChatGoogleGenerativeAI({
        model: "gemini-1.5-pro",
        temperature: 0,
        maxOutputTokens: 1000,
        maxRetries: 2,
    });

    const prompt = new PromptTemplate({
        inputVariables: ["results"],
        template: `
        You are a smart fake news detector. Crawl the web and trusted websites to verify if the provided information is legitimate.
        
        Output instructions:
        Provide a percentage indicating how likely the news is fake.
        
        {results}
        
        Summary:
        `
    });

    const llmChain = new LLMChain({ llm, prompt });
    const summary = await llmChain.invoke({ results: searchResults });
    return summary;
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
    console.log("API======");
    
    if (req.method !== 'POST') {
        return res.status(405).json({ error: 'Method Not Allowed' });
    }

    const { query } = req.body;
    if (!query) {
        return res.status(400).json({ error: 'Query is required' });
    }

    try {
        const result = await searchAndSummarize(query);
        return res.status(200).json({ query, result });
    } catch (error:any) {
        return res.status(500).json({ error: error.message });
    }
}
